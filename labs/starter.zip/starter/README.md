# 本機量化學習實習包

這是教學程式，不是投資產品或實盤 bot。沒有券商介面、帳戶登入、API key、行情下載或網絡操作。全部市場數據由假設函數生成；不能用它證明金融優勢。

需要 Python 3.9 或以上，無第三方依賴。macOS / Linux 用 `python3`；Windows 可用已安裝 Python 的 `py`。在解壓後的本目錄開終端機執行。

## 1. 先跑驗收

```text
python3 -m unittest discover -s tests -v
```

應顯示 29 項測試通過。涵蓋風險與現金邊界、NaN、時間與 OHLC、下一 bar 執行、截斷後過去決策不變、同 bar 止賺／止蝕歧義，以及本機訂單 ledger 的去重、衝突與恢復。

## 2. 日線研究示例

```text
python3 run_research.py --data data/synthetic_daily.csv --output runs/daily-01
```

資料是 90 根假日線。timestamp 定義為假設 6.5 小時 bar 的起點，完整 close 的可得時間是起點 + 6.5 小時。下一根 open 執行前一根完成 close 的均線條件；固定投入當時現金的 50%，只買整股，買賣收固定費並加不利滑價；期末以假設 close 平倉並收費。

輸出 `config.json / summary.json / trades.csv / equity.csv / decisions.csv / manifest.json`。固定目錄已存在即拒絕，不覆寫。輸入驗證失敗另存 `failure.json`，程式退出碼 5；正常完成為 0，正式判定仍是 `EDUCATIONAL_ONLY`。

這裡沒有日曆、拆股、股息、稅、T+1、多貨幣、孖展或真實撮合。日期與時區均為合成學習資料，不可當 NYSE 真實交易日曆；不使用 real market data。

## 3. 日內 ORB 示例

```text
python3 run_research.py --data data/synthetic_intraday.csv --strategy orb --fee 0.2 --bps 2 --output runs/orb-01
```

每個假 session 首五根一分鐘 bar 定義區間。區間完成後的收盤突破才產生訊號，下一分鐘 open 入場；每個 session 最多一次入場嘗試。按模擬 session 初資金 0.5% 風險、區間低點、兩邊費用及止蝕不利滑價限制整股數，另有現金限制；目標是兩倍價差。

同 bar 涵蓋 stop 與 target 時採 stop-first，`ambiguous_intrabar_exits` 會計數；跳空低於 stop 用較差 open；session 最後 bar 強制退出。只有 OHLC 的近似路徑，沒有 tick 順序或成交量限制，不能當真實執行證據。費用、滑價與止蝕均非損失封頂保證。

## 4. 本機訂單事件練習

```text
python3 order_lab.py --state runs/duplicate.json --scenario duplicate
python3 order_lab.py --state runs/unknown.json --scenario unknown
python3 order_lab.py --state runs/conflict.json --scenario conflict
```

duplicate：同 fill ID 同內容不重複加倉，4+2 共6股。unknown / conflict：保存 raw、halted=true、退出碼5。已有狀態時只讀回，不新派發；需有新教學實驗時自行選新檔名，不刪原始證據。

這不是 broker exactly-once 系統：只有一個本機寫入者，沒有網絡、鎖管理、完整帳戶對帳、取消狀態機或生產安全保障。不要把它接到券商。

## 5. 自己動手

1. 改費用後用另一個 run 目錄，比較交易、現金與結果，解釋差異。
2. 複製資料，再製造 NaN、重複時間或錯 OHLC；原檔保持不變，觀察拒絕。
3. 先手算四根 bar，再對照測試 `test_accounting_hand_calculation`。
4. 增加未知事件、重複不同內容與缺 reference 的測試。
5. 寫明你沒有模擬到的風險，而不為了得到 ACCEPTED 刪掉限制。

修改後先跑測試。測試全綠只表示已測契約，不表示方法正確、真實市場盈利或獲准實盤。
