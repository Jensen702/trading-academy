"""Immutable run directory, synthetic-data backtest and evidence manifest."""
from pathlib import Path
import argparse, csv, hashlib, json, sys
from datetime import datetime, timezone
from engine import load_bars, daily_sma, intraday_orb

def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write_csv(path,rows):
    if not rows: path.write_text('',encoding='utf-8');return
    with path.open('w',newline='',encoding='utf-8') as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
def main():
    p=argparse.ArgumentParser(description='Synthetic educational backtest, never live trading.')
    p.add_argument('--data',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--strategy',choices=['daily','orb'],default='daily');p.add_argument('--initial',type=float,default=1000)
    p.add_argument('--fee',type=float,default=1);p.add_argument('--bps',type=float,default=5);p.add_argument('--lookback',type=int,default=3)
    args=p.parse_args()
    if args.output.exists(): raise SystemExit('COLLISION: run directory exists; nothing overwritten.')
    # Reserve directory before validation so failures have a separate immutable evidence location.
    args.output.mkdir(parents=True,exist_ok=False)
    config={'strategy':args.strategy,'initial':args.initial,'fee_per_order':args.fee,'slippage_bps':args.bps,'lookback_daily_only':args.lookback,'mode':'LOCAL_SYNTHETIC_BACKTEST'}
    (args.output/'config.json').write_text(json.dumps(config,indent=2),encoding='utf-8')
    try:
        data=load_bars(args.data)
        if args.strategy=='daily': result=daily_sma(data,args.initial,args.lookback,args.fee,args.bps)
        else: result=intraday_orb(data,args.initial,fee=args.fee,bps=args.bps)
        summary,trades,equity,decisions=result
        (args.output/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False),encoding='utf-8')
        for name,rows in [('trades',trades),('equity',equity),('decisions',decisions)]: write_csv(args.output/(name+'.csv'),rows)
        manifest={'created_at':datetime.now(timezone.utc).isoformat(),'data':str(args.data.resolve()),'data_sha256':digest(args.data),'code':{name:digest(Path(__file__).parent/name) for name in ['engine.py','run_research.py']},'files':{path.name:digest(path) for path in args.output.iterdir() if path.is_file()},'status':'COMPLETED_EDUCATIONAL_ONLY'}
        (args.output/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
        print(json.dumps(summary,indent=2))
    except Exception as exc:
        (args.output/'failure.json').write_text(json.dumps({'status':'FAILED','error_type':type(exc).__name__,'error':str(exc)}),encoding='utf-8')
        print(f'FAILED: {exc}',file=sys.stderr);return 5
    return 0
if __name__=='__main__': raise SystemExit(main())
