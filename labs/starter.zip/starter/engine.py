"""Teaching-only historical simulator: synthetic data; no broker adapter or network."""
from dataclasses import dataclass
from datetime import datetime, timedelta
import csv, math

@dataclass(frozen=True)
class Bar:
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float

def load_bars(path):
    bars = []
    with open(path, newline='', encoding='utf-8') as handle:
        reader = csv.DictReader(handle)
        expected = ['timestamp', 'open', 'high', 'low', 'close', 'volume']
        if reader.fieldnames != expected:
            raise ValueError('CSV schema must be timestamp,open,high,low,close,volume')
        for row in reader:
            ts = datetime.fromisoformat(row['timestamp'].replace('Z', '+00:00'))
            if ts.tzinfo is None: raise ValueError('timestamp must include timezone')
            values = [float(row[k]) for k in expected[1:]]
            if not all(math.isfinite(v) for v in values): raise ValueError('non-finite data')
            o,h,l,c,v = values
            if min(o,h,l,c) <= 0 or v < 0 or h < max(o,l,c) or l > min(o,h,c):
                raise ValueError('invalid OHLCV')
            if bars and ts <= bars[-1].timestamp: raise ValueError('duplicate or unsorted timestamp')
            bars.append(Bar(ts,o,h,l,c,v))
    if len(bars) < 2: raise ValueError('at least two bars required')
    return bars

def size_long(cash, risk_budget, entry, stop, fee, per_share_buffer=0):
    values = (cash,risk_budget,entry,stop,fee,per_share_buffer)
    if not all(math.isfinite(x) for x in values): raise ValueError('non-finite input')
    if cash < 0 or risk_budget < 0 or fee < 0 or per_share_buffer < 0 or not 0 < stop < entry:
        raise ValueError('invalid risk input')
    by_risk = max(0, math.floor((risk_budget-fee)/(entry-stop+per_share_buffer)))
    by_cash = max(0, math.floor((cash-fee)/(entry+per_share_buffer)))
    return min(by_risk, by_cash)

def validate_config(initial, fee, bps):
    if not all(math.isfinite(x) for x in (initial,fee,bps)):
        raise ValueError('non-finite configuration')
    if initial <= 0 or fee < 0 or not 0 <= bps < 10000:
        raise ValueError('invalid capital/fee/slippage')

def summarize(initial, cash, trades, equity, ambiguous=0):
    peak=initial; mdd=0
    for row in equity:
        peak=max(peak,row['equity']); mdd=max(mdd,1-row['equity']/peak)
    return {'initial':initial, 'ending_cash':cash, 'net_pnl':cash-initial,
            'net_return':cash/initial-1, 'max_drawdown':mdd,
            'order_fills':len(trades), 'completed_round_trips':sum(t['side']=='SELL' for t in trades),
            'fees':sum(t['fee'] for t in trades), 'ambiguous_intrabar_exits':ambiguous,
            'mode':'LOCAL_SYNTHETIC_BACKTEST', 'verdict':'EDUCATIONAL_ONLY',
            'limitations':['Synthetic data do not establish market advantage.',
              'No liquidity, queue position, partial fills or real broker execution.',
              'No T+1, corporate actions, multi-currency, taxes or margin model.',
              'Daily marks may omit intrabar excursions; intraday ordering is an assumption.',
              'Neither backtest nor unit tests authorise live orders.']}

def daily_sma(bars, initial=1000, lookback=3, fee=1, bps=5, allocation=0.5):
    validate_config(initial,fee,bps)
    if isinstance(lookback,bool) or not isinstance(lookback,int) or lookback<2: raise ValueError('lookback must be integer >=2')
    if not math.isfinite(allocation) or not 0 < allocation <= 1: raise ValueError('allocation must be (0,1]')
    if any(b.timestamp-a.timestamp <= timedelta(hours=6,minutes=30) for a,b in zip(bars,bars[1:])):
        raise ValueError('daily lab requires non-overlapping 6.5-hour bars')
    cash=initial; qty=0; pending=None; signal_at=None; closes=[]; trades=[]; equity=[]; decisions=[]
    for bar in bars:
        if pending is True and qty==0:
            price=bar.open*(1+bps/10000)
            n=max(0,math.floor((cash*allocation-fee)/price))
            if n:
                cash-=n*price+fee; qty=n
                trades.append({'timestamp':bar.timestamp.isoformat(),'signal_at':signal_at,'side':'BUY','qty':n,'price':price,'fee':fee,'reason':'previous_completed_close','execution_model':'next_bar_open_plus_slippage'})
        elif pending is False and qty:
            price=bar.open*(1-bps/10000); cash+=qty*price-fee
            trades.append({'timestamp':bar.timestamp.isoformat(),'signal_at':signal_at,'side':'SELL','qty':qty,'price':price,'fee':fee,'reason':'previous_completed_close','execution_model':'next_bar_open_plus_slippage'}); qty=0
        closes.append(bar.close)
        pending=bar.close>sum(closes[-lookback:])/lookback if len(closes)>=lookback else None
        signal_at=(bar.timestamp+timedelta(hours=6,minutes=30)).isoformat()
        decisions.append({'available_at':signal_at,'target_long':pending,'data_end':bar.timestamp.isoformat()})
        equity.append({'timestamp':signal_at,'cash':cash,'qty':qty,'mark':bar.close,'equity':cash+qty*bar.close})
    if qty:
        bar=bars[-1];price=bar.close*(1-bps/10000);cash+=qty*price-fee
        trades.append({'timestamp':signal_at,'signal_at':None,'side':'SELL','qty':qty,'price':price,'fee':fee,'reason':'forced_end_of_sample','execution_model':'final_close_plus_slippage'});qty=0
        equity[-1]={'timestamp':signal_at,'cash':cash,'qty':0,'mark':bar.close,'equity':cash}
    return summarize(initial,cash,trades,equity),trades,equity,decisions

def intraday_orb(bars, initial=1000, opening_bars=5, risk_fraction=0.005, fee=0.2, bps=2):
    validate_config(initial,fee,bps)
    if isinstance(opening_bars,bool) or not isinstance(opening_bars,int) or opening_bars<1: raise ValueError('invalid opening_bars')
    if not math.isfinite(risk_fraction) or not 0<risk_fraction<=0.05: raise ValueError('risk_fraction must be (0,.05]')
    sessions={}
    for bar in bars: sessions.setdefault(bar.timestamp.date().isoformat(),[]).append(bar)
    cash=initial;trades=[];equity=[];decisions=[];ambiguous=0
    for session,rows in sessions.items():
        if len(rows)<opening_bars+2: raise ValueError('not enough intraday bars')
        if any(b.timestamp-a.timestamp!=timedelta(minutes=1) for a,b in zip(rows,rows[1:])):
            raise ValueError('intraday lab requires continuous one-minute bars in each synthetic session')
        hi=max(b.high for b in rows[:opening_bars]);lo=min(b.low for b in rows[:opening_bars])
        qty=0;pending=False;traded=False;entry=target=None;budget=cash*risk_fraction
        for i,bar in enumerate(rows):
            if pending and not traded:
                pending=False;traded=True;entry=bar.open*(1+bps/10000)
                if entry>lo:
                    # Reserve both commissions, plus adverse stop slippage in risk sizing.
                    qty=size_long(cash,budget,entry,lo,2*fee,lo*bps/10000)
                    if qty:
                        target=entry+2*(entry-lo);cash-=qty*entry+fee
                        trades.append({'timestamp':bar.timestamp.isoformat(),'signal_at':(rows[i-1].timestamp+timedelta(minutes=1)).isoformat(),'side':'BUY','qty':qty,'price':entry,'fee':fee,'reason':'completed_range_breakout','execution_model':'next_minute_open_plus_slippage'})
            if qty:
                stop_hit=bar.low<=lo;target_hit=bar.high>=target;reason=None;reference=None
                if stop_hit and target_hit: ambiguous+=1
                if stop_hit: reason='stop_first_assumption';reference=min(bar.open,lo)
                elif target_hit: reason='target_assumption';reference=target
                elif i==len(rows)-1: reason='synthetic_session_end';reference=bar.close
                if reason:
                    price=reference*(1-bps/10000);cash+=qty*price-fee
                    trades.append({'timestamp':(bar.timestamp+timedelta(minutes=1)).isoformat(),'signal_at':None,'side':'SELL','qty':qty,'price':price,'fee':fee,'reason':reason,'execution_model':'assumed_intrabar_path_not_tick_replay'});qty=0
            signal=i>=opening_bars and i<len(rows)-1 and not traded and bar.close>hi
            if signal: pending=True
            available=(bar.timestamp+timedelta(minutes=1)).isoformat()
            decisions.append({'available_at':available,'target_long':signal,'session':session,'range_high':hi if i>=opening_bars else None,'range_low':lo if i>=opening_bars else None})
            equity.append({'timestamp':available,'cash':cash,'qty':qty,'mark':bar.close,'equity':cash+qty*bar.close})
    return summarize(initial,cash,trades,equity,ambiguous),trades,equity,decisions
