import csv, json, tempfile, unittest
from pathlib import Path
from datetime import datetime, timedelta, timezone
from engine import Bar, load_bars, size_long, daily_sma, intraday_orb
from order_lab import Ledger
BASE=datetime(2026,1,5,14,30,tzinfo=timezone.utc)
def daily(prices): return [Bar(BASE+timedelta(days=i),p,p,p,p,100) for i,p in enumerate(prices)]
def minute(prices): return [Bar(BASE+timedelta(minutes=i),p,p+.05,p-.05,p,100) for i,p in enumerate(prices)]
class RiskTests(unittest.TestCase):
 def test_worked_example(self): self.assertEqual(size_long(2000,10,30,29.6,2,.02),19)
 def test_cash_boundary(self): self.assertEqual(size_long(100,100,33,32,1),3)
 def test_cash_just_over_boundary(self): self.assertEqual(size_long(100,100,33.01,32,1),2)
 def test_fee_exceeds_risk(self): self.assertEqual(size_long(100,1,20,19,2),0)
 def test_stop_above_entry(self):
  with self.assertRaises(ValueError): size_long(100,1,20,21,0)
 def test_nan(self):
  with self.assertRaises(ValueError): size_long(100,1,float('nan'),19,0)
 def test_zero_stop(self):
  with self.assertRaises(ValueError): size_long(100,1,20,0,0)
class DataTests(unittest.TestCase):
 def write(self,rows):
  d=tempfile.TemporaryDirectory();self.addCleanup(d.cleanup);p=Path(d.name)/'data.csv'
  with p.open('w',newline='') as f:
   w=csv.writer(f);w.writerow(['timestamp','open','high','low','close','volume']);w.writerows(rows)
  return p
 def test_valid(self): self.assertEqual(len(load_bars(self.write([['2026-01-01T00:00:00Z',10,11,9,10,100],['2026-01-02T00:00:00Z',11,12,10,11,100]]))),2)
 def test_invalid_ohlc(self):
  with self.assertRaises(ValueError): load_bars(self.write([['2026-01-01T00:00:00Z',10,9,8,10,100]]))
 def test_duplicate_timestamp(self):
  row=['2026-01-01T00:00:00Z',10,11,9,10,100]
  with self.assertRaises(ValueError): load_bars(self.write([row,row]))
 def test_no_timezone(self):
  with self.assertRaises(ValueError): load_bars(self.write([['2026-01-01T00:00:00',10,11,9,10,100]]))
 def test_nonfinite(self):
  with self.assertRaises(ValueError): load_bars(self.write([['2026-01-01T00:00:00Z','nan',11,9,10,100]]))
class ResearchTests(unittest.TestCase):
 def test_signal_cannot_fill_same_close(self):
  _,t,_,_=daily_sma(daily([20,21,22,23]),100,2,1,0)
  self.assertEqual(t[0]['timestamp'],daily([20,21,22,23])[2].timestamp.isoformat());self.assertGreater(datetime.fromisoformat(t[0]['timestamp']),datetime.fromisoformat(t[0]['signal_at']))
 def test_accounting_hand_calculation(self):
  s,t,e,_=daily_sma(daily([20,21,22,23]),100,2,1,0)
  self.assertEqual(t[0]['qty'],2);self.assertEqual(s['ending_cash'],100);self.assertEqual(s['fees'],2);self.assertEqual(e[-1]['qty'],0)
 def test_future_extension_does_not_rewrite_decisions(self): self.assertEqual(daily_sma(daily([20,21,22,23,24]),lookback=2)[3],daily_sma(daily([20,21,22,23,24,10,30]),lookback=2)[3][:5])
 def test_negative_fee_rejected(self):
  with self.assertRaises(ValueError): daily_sma(daily([20,21,22]),fee=-1)
 def test_daily_rejects_intraday_frequency(self):
  with self.assertRaises(ValueError): daily_sma(minute([20,21,22]))
 def test_orb_no_entry_before_completed_range(self):
  _,t,_,_=intraday_orb(minute([20,20,20,20,20,20.2,20.3,20.4,20.2]),fee=0,bps=0)
  self.assertTrue(t);self.assertGreaterEqual(datetime.fromisoformat(t[0]['timestamp']),BASE+timedelta(minutes=6))
 def test_orb_ambiguous_bar_uses_stop(self):
  rows=minute([20,20,20,20,20,20.2,20.3,20.4,20.2]);b=rows[6];rows[6]=Bar(b.timestamp,b.open,22,19,b.close,b.volume)
  s,t,_,_=intraday_orb(rows,fee=0,bps=0);self.assertEqual(s['ambiguous_intrabar_exits'],1);self.assertEqual(t[1]['reason'],'stop_first_assumption')
 def test_orb_missing_minute_rejected(self):
  rows=minute([20]*10);rows.pop(6)
  with self.assertRaises(ValueError): intraday_orb(rows)
class EventTests(unittest.TestCase):
 def setUp(self):
  self.dir=tempfile.TemporaryDirectory();self.addCleanup(self.dir.cleanup);self.path=Path(self.dir.name)/'state.json';self.ledger=Ledger(self.path);self.ledger.dispatch('o1',10)
 def fill(self,n=4): return {'type':'fill','order_id':'o1','fill_id':'f1','qty':n}
 def test_exact_duplicate_is_idempotent(self):
  self.ledger.apply(self.fill());self.ledger.apply(self.fill());self.assertEqual(self.ledger.state['orders']['o1']['filled'],4)
 def test_conflicting_duplicate_halts_and_preserves_raw(self):
  self.ledger.apply(self.fill())
  with self.assertRaises(ValueError): self.ledger.apply(self.fill(5))
  self.assertTrue(self.ledger.state['halted']);self.assertEqual(self.ledger.state['raw'][-1]['qty'],5)
 def test_overfill_rejected(self):
  with self.assertRaises(ValueError): self.ledger.apply(self.fill(11))
 def test_unknown_is_not_permission_to_resend(self):
  with self.assertRaises(ValueError): self.ledger.apply({'type':'unknown','order_id':'o1'})
  with self.assertRaises(ValueError): self.ledger.dispatch('o2',10)
  self.assertEqual(self.ledger.state['orders']['o1']['status'],'UNKNOWN')
 def test_restore_does_not_redispatch(self):
  self.ledger.apply(self.fill());r=Ledger(self.path);self.assertEqual(r.state['orders']['o1']['filled'],4)
  with self.assertRaises(ValueError): r.dispatch('o1',10)
  self.assertEqual(len([e for e in r.state['raw'] if e['type']=='dispatch']),1)
 def test_unknown_event_shape_halts(self):
  with self.assertRaises(ValueError): self.ledger.apply({'type':'surprise','order_id':'o1'})
  self.assertTrue(self.ledger.state['halted'])
 def test_saved_reference_mismatch_rejected(self):
  self.ledger.apply(self.fill());s=json.loads(self.path.read_text());s['orders']['o1']['filled']=0;self.path.write_text(json.dumps(s))
  with self.assertRaises(ValueError): Ledger(self.path)
 def test_orphan_fill_rejected_on_restore(self):
  s=json.loads(self.path.read_text());s['fills']['bad']={'order_id':'missing','qty':1};self.path.write_text(json.dumps(s))
  with self.assertRaises(ValueError): Ledger(self.path)
 def test_quantity_shape(self):
  with self.assertRaises(ValueError): self.ledger.apply(self.fill(1.5))
if __name__=='__main__': unittest.main()
