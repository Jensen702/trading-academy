"""Local event ledger only. No network, credentials or broker execution."""
from pathlib import Path
import argparse, copy, json, os, tempfile

def atomic_write(path,state):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile('w',dir=path.parent,delete=False,encoding='utf-8') as f:
        json.dump(state,f,indent=2);f.flush();os.fsync(f.fileno());name=f.name
    os.replace(name,path)
    # Teaching scope: one writer. No claim of cross-process locking or broker exactly-once.

class Ledger:
    def __init__(self,path):
        self.path=Path(path)
        self.state=json.loads(self.path.read_text()) if self.path.exists() else {'schema':1,'orders':{},'fills':{},'raw':[],'halted':False}
        self.validate()
    def validate(self):
        s=self.state
        if s.get('schema')!=1 or not isinstance(s.get('orders'),dict) or not isinstance(s.get('fills'),dict) or not isinstance(s.get('raw'),list): raise ValueError('invalid ledger schema')
        for order_id,o in s['orders'].items():
            if o.get('status') not in ['DISPATCH_RECORDED','ACCEPTED','PARTIAL','FILLED','UNKNOWN']: raise ValueError('unknown saved status')
            expected=sum(f['qty'] for f in s['fills'].values() if f['order_id']==order_id)
            if o.get('filled')!=expected or not 0<=expected<=o['qty']: raise ValueError('saved fill reference mismatch')
        for f in s['fills'].values():
            if f['order_id'] not in s['orders']: raise ValueError('orphan fill')
    def record(self,event):
        self.state['raw'].append(copy.deepcopy(event));atomic_write(self.path,self.state)
    def fail(self,msg):
        self.state['halted']=True;atomic_write(self.path,self.state);raise ValueError(msg)
    def dispatch(self,order_id,qty):
        if self.state['halted']: raise ValueError('ledger halted; no new dispatch')
        if not isinstance(qty,int) or isinstance(qty,bool) or qty<=0: raise ValueError('invalid integer quantity')
        if order_id in self.state['orders']: raise ValueError('existing dispatch; never automatically resend')
        self.state['orders'][order_id]={'qty':qty,'filled':0,'status':'DISPATCH_RECORDED'}
        self.record({'type':'dispatch','order_id':order_id,'qty':qty})
    def apply(self,event):
        if self.state['halted']: raise ValueError('ledger halted; reconciliation required')
        self.record(event)
        if event.get('type') not in ['accepted','fill','unknown']: self.fail('unsupported event')
        oid=event.get('order_id');o=self.state['orders'].get(oid)
        if o is None: self.fail('orphan event')
        if event['type']=='unknown': o['status']='UNKNOWN';self.fail('unknown outcome; do not resend')
        if event['type']=='accepted':
            if o['status']=='DISPATCH_RECORDED': o['status']='ACCEPTED'
        else:
            fid=event.get('fill_id');n=event.get('qty')
            if not isinstance(fid,str) or not fid or not isinstance(n,int) or isinstance(n,bool) or n<=0: self.fail('invalid fill shape')
            item={'order_id':oid,'qty':n}
            if fid in self.state['fills']:
                if self.state['fills'][fid]!=item: self.fail('same fill ID with conflicting content')
            else:
                if o['filled']+n>o['qty']: self.fail('overfill')
                self.state['fills'][fid]=item;o['filled']+=n
                o['status']='FILLED' if o['filled']==o['qty'] else 'PARTIAL'
        self.validate();atomic_write(self.path,self.state)

def main():
    p=argparse.ArgumentParser();p.add_argument('--state',type=Path,required=True);p.add_argument('--scenario',choices=['duplicate','unknown','conflict'],required=True);a=p.parse_args()
    if a.state.exists():
        ledger=Ledger(a.state);print('EXISTING STATE: restored read-only; no new dispatch.');print(json.dumps(ledger.state,indent=2));return 0
    ledger=Ledger(a.state);ledger.dispatch('demo-order',10)
    try:
        ledger.apply({'type':'accepted','order_id':'demo-order'})
        if a.scenario=='unknown': ledger.apply({'type':'unknown','order_id':'demo-order'})
        else:
            f={'type':'fill','order_id':'demo-order','fill_id':'f1','qty':4};ledger.apply(f)
            ledger.apply({**f,'qty':5} if a.scenario=='conflict' else f)
            ledger.apply({'type':'fill','order_id':'demo-order','fill_id':'f2','qty':2})
    except ValueError as e:
        print('HALTED:',e);print(json.dumps(ledger.state,indent=2));return 5
    print(json.dumps(ledger.state,indent=2));return 0
if __name__=='__main__': raise SystemExit(main())
